import { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';
import { openEmail, openWhatsApp } from '../utils/linking';

export default function ContactScreen() {
  const { t } = useI18n();
  const { width } = useWindowDimensions();
  const titleSize = width < 390 ? 24 : 28;
  const [form, setForm] = useState({ name: '', email: '', model: '', message: '' });
  const whatsappNumber = '212608188138';
  const emailAddress = 'hello@ridekey.studio';

  const lines = useMemo(() => {
    return [
      t.contact.messageIntro,
      `${t.contact.nameLabel}: ${form.name || '-'}`,
      `${t.contact.emailLabel}: ${form.email || '-'}`,
      `${t.contact.modelLabel}: ${form.model || '-'}`,
      `${t.contact.messageLabel}: ${form.message || '-'}`
    ];
  }, [form, t]);

  const handleWhatsApp = () => openWhatsApp(whatsappNumber, lines.join('\n'));
  const handleEmail = () =>
    openEmail({
      to: emailAddress,
      subject: t.contact.emailSubject,
      body: lines.join('\n')
    });

  return (
    <ScreenContainer>
      <View style={styles.wrap}>
        <Text style={styles.badge}>{t.nav.contact}</Text>
        <Text style={[styles.title, { fontSize: titleSize }]}>{t.contact.title}</Text>
        <View style={styles.card}>
          <TextInput style={styles.input} placeholderTextColor="#94A3B8" placeholder={t.contact.namePlaceholder} value={form.name} onChangeText={(value) => setForm({ ...form, name: value })} />
          <TextInput style={styles.input} placeholderTextColor="#94A3B8" placeholder={t.contact.emailPlaceholder} value={form.email} onChangeText={(value) => setForm({ ...form, email: value })} autoCapitalize="none" keyboardType="email-address" />
          <TextInput style={styles.input} placeholderTextColor="#94A3B8" placeholder={t.contact.modelPlaceholder} value={form.model} onChangeText={(value) => setForm({ ...form, model: value })} />
          <TextInput style={[styles.input, styles.area]} multiline placeholderTextColor="#94A3B8" placeholder={t.contact.messagePlaceholder} value={form.message} onChangeText={(value) => setForm({ ...form, message: value })} />

          <Pressable style={styles.primary} onPress={handleWhatsApp}><Text style={styles.primaryText}>{t.contact.sendWhatsapp}</Text></Pressable>
          <Pressable style={styles.secondary} onPress={handleEmail}><Text style={styles.secondaryText}>{t.contact.sendEmail}</Text></Pressable>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>{t.contact.hoursTitle}</Text>
          <Text style={styles.infoText}>{t.contact.hoursWeek}</Text>
          <Text style={styles.infoText}>{t.contact.hoursWeekend}</Text>
          <Text style={styles.infoTitle}>{t.contact.showroomTitle}</Text>
          <Text style={styles.infoText}>415 Ridekey Avenue, San Francisco, CA 94107</Text>
          <Text style={styles.infoTitle}>{t.contact.contactTitle}</Text>
          <Text style={styles.infoText}>hello@ridekey.studio</Text>
          <Text style={styles.infoText}>+1 (415) 555-0188</Text>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  wrap: { marginTop: 12 },
  badge: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  title: { color: theme.colors.white, fontWeight: '700', marginTop: 6 },
  card: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 16, borderWidth: 1, gap: 10, marginTop: 10, padding: 12 },
  input: { backgroundColor: '#0B0F1A', borderColor: 'rgba(255,255,255,0.12)', borderRadius: 10, borderWidth: 1, color: theme.colors.white, paddingHorizontal: 12, paddingVertical: 10 },
  area: { minHeight: 110, textAlignVertical: 'top' },
  primary: { backgroundColor: theme.colors.accent, borderRadius: 10, padding: 12 },
  primaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  secondary: { backgroundColor: '#475569', borderRadius: 10, padding: 12 },
  secondaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  infoCard: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 16, borderWidth: 1, gap: 6, marginTop: 10, padding: 12 },
  infoTitle: { color: theme.colors.white, fontWeight: '700', marginTop: 6 },
  infoText: { color: '#CBD5E1' }
});
