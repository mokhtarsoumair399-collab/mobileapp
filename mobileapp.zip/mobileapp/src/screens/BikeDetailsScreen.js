import Checkbox from 'expo-checkbox';
import { useEffect, useMemo, useState } from 'react';
import { Image, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import SmartImage from '../components/SmartImage';
import { bikes } from '../data/bikes';
import { gearItems } from '../data/gear';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';
import { formatMAD } from '../utils/formatCurrency';

const todayIso = () => new Date().toISOString().split('T')[0];
const addDays = (iso, days) => {
  const date = new Date(iso);
  date.setDate(date.getDate() + days);
  return date.toISOString().split('T')[0];
};

export default function BikeDetailsScreen({ route, navigation }) {
  const { id } = route.params || {};
  const { t, lang } = useI18n();
  const { width } = useWindowDimensions();
  const [heroRatio, setHeroRatio] = useState(16 / 9);
  const heroHeight = Math.min(Math.max(width / heroRatio, 210), 380);
  const galleryWidth = width < 390 ? 110 : 130;
  const titleSize = width < 390 ? 25 : 30;
  const sectionSize = width < 390 ? 19 : 21;
  const compact = width < 360;
  const bike = bikes.find((item) => item.id === id);
  const [previewUri, setPreviewUri] = useState(null);
  const [selectedGearIds, setSelectedGearIds] = useState([]);
  const [rental, setRental] = useState({
    name: '',
    phone: '',
    startDate: todayIso(),
    endDate: addDays(todayIso(), 1),
    pickupTime: '10:00',
    returnTime: '18:00'
  });

  const toggleGear = (gearId) => {
    setSelectedGearIds((prev) => (prev.includes(gearId) ? prev.filter((idItem) => idItem !== gearId) : [...prev, gearId]));
  };

  const checkoutParams = useMemo(() => {
    return {
      select: bike?.id,
      gear: selectedGearIds,
      renterName: rental.name,
      renterPhone: rental.phone,
      startDate: rental.startDate,
      endDate: rental.endDate,
      pickupTime: rental.pickupTime,
      returnTime: rental.returnTime
    };
  }, [bike?.id, rental, selectedGearIds]);

  useEffect(() => {
    if (!bike?.image) return;
    Image.getSize(bike.image, (imgWidth, imgHeight) => {
      if (imgWidth > 0 && imgHeight > 0) setHeroRatio(imgWidth / imgHeight);
    }, () => {});
  }, [bike?.image]);

  if (!bike) {
    return (
      <ScreenContainer>
        <Text style={styles.notFound}>{t.details.notFound}</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <View style={styles.wrap}>
        <Pressable onPress={() => setPreviewUri(bike.image)}>
          <Image source={{ uri: bike.image }} style={[styles.hero, { height: heroHeight }]} resizeMode="contain" />
        </Pressable>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.galleryRow}>
          {bike.gallery.map((photo, index) => (
            <Pressable key={`${photo}-${index}`} onPress={() => setPreviewUri(photo)}>
              <Image source={{ uri: photo }} style={[styles.galleryImage, { width: galleryWidth }]} resizeMode="contain" />
            </Pressable>
          ))}
        </ScrollView>

        <Text style={styles.brand}>{bike.brand}</Text>
        <Text style={[styles.title, { fontSize: titleSize }]}>{bike.name}</Text>
        <Text style={styles.price}>{formatMAD(bike.price, lang)}</Text>
        <Text style={styles.description}>{bike.description}</Text>

        <View style={styles.specCard}>
          <Text style={styles.spec}>{t.details.engine}: {bike.engine}</Text>
          <Text style={styles.spec}>{t.details.displacement}: {bike.displacement}</Text>
          <Text style={styles.spec}>{t.details.torque}: {bike.torque}</Text>
          <Text style={styles.spec}>{t.details.topSpeed}: {bike.topSpeed}</Text>
        </View>

        <Text style={[styles.section, { fontSize: sectionSize }]}>{t.rentals.title}</Text>
        <TextInput style={styles.input} placeholder={t.rentals.renterName} placeholderTextColor="#94A3B8" value={rental.name} onChangeText={(v) => setRental({ ...rental, name: v })} />
        <TextInput style={styles.input} placeholder={t.rentals.renterPhone} placeholderTextColor="#94A3B8" value={rental.phone} onChangeText={(v) => setRental({ ...rental, phone: v })} />
        <TextInput style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor="#94A3B8" value={rental.startDate} onChangeText={(v) => setRental({ ...rental, startDate: v })} />
        <TextInput style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor="#94A3B8" value={rental.endDate} onChangeText={(v) => setRental({ ...rental, endDate: v })} />
        <TextInput style={styles.input} placeholder="10:00" placeholderTextColor="#94A3B8" value={rental.pickupTime} onChangeText={(v) => setRental({ ...rental, pickupTime: v })} />
        <TextInput style={styles.input} placeholder="18:00" placeholderTextColor="#94A3B8" value={rental.returnTime} onChangeText={(v) => setRental({ ...rental, returnTime: v })} />

        <Text style={[styles.section, { fontSize: sectionSize }]}>{t.bikes.accessoriesTitle}</Text>
        {gearItems.map((item) => (
          <View key={item.id} style={[styles.gearRow, compact && styles.gearRowCompact]}>
            <SmartImage
              uri={item.image}
              style={[styles.gearImage, compact && styles.gearImageCompact]}
              resizeMode="cover"
              fallbackText={item.name}
            />
            <View style={{ flex: 1 }}>
              <Text style={styles.gearName}>{item.name}</Text>
              <Text style={styles.gearPrice}>{item.price}</Text>
            </View>
            <Checkbox value={selectedGearIds.includes(item.id)} onValueChange={() => toggleGear(item.id)} color={theme.colors.accent} />
          </View>
        ))}

        <Pressable style={styles.primary} onPress={() => navigation.navigate('Bikes', checkoutParams)}>
          <Text style={styles.primaryText}>{t.details.book}</Text>
        </Pressable>
        <Pressable style={styles.secondary} onPress={() => navigation.navigate('Contact')}>
          <Text style={styles.secondaryText}>{t.details.contact}</Text>
        </Pressable>
        <Modal visible={!!previewUri} transparent animationType="fade" onRequestClose={() => setPreviewUri(null)}>
          <Pressable style={styles.previewBackdrop} onPress={() => setPreviewUri(null)}>
            <Image source={{ uri: previewUri || bike.image }} style={styles.previewImage} resizeMode="contain" />
            <Text style={styles.previewHint}>Tap to close</Text>
          </Pressable>
        </Modal>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  wrap: { marginTop: 10 },
  notFound: { color: theme.colors.white, fontSize: 24, fontWeight: '700', marginTop: 20 },
  hero: { backgroundColor: theme.colors.night, borderRadius: 18, width: '100%' },
  galleryRow: { gap: 8, marginTop: 8 },
  galleryImage: { aspectRatio: 16 / 9, backgroundColor: theme.colors.night, borderRadius: 12, width: 130 },
  brand: { color: theme.colors.accent, marginTop: 12, textTransform: 'uppercase' },
  title: { color: theme.colors.white, fontWeight: '700' },
  price: { color: theme.colors.accent, fontSize: 24, fontWeight: '700', marginTop: 4 },
  description: { color: '#CBD5E1', marginTop: 8 },
  specCard: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 12, borderWidth: 1, marginTop: 12, padding: 10 },
  spec: { color: '#CBD5E1', marginTop: 4 },
  section: { color: theme.colors.white, fontWeight: '700', marginTop: 12 },
  input: { backgroundColor: '#0B0F1A', borderColor: 'rgba(255,255,255,0.12)', borderRadius: 10, borderWidth: 1, color: theme.colors.white, marginTop: 8, paddingHorizontal: 12, paddingVertical: 10 },
  gearRow: { alignItems: 'center', backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 12, borderWidth: 1, flexDirection: 'row', gap: 10, marginTop: 8, padding: 8 },
  gearRowCompact: { alignItems: 'flex-start', flexDirection: 'column' },
  gearImage: { backgroundColor: theme.colors.ink, borderRadius: 8, height: 54, width: 54 },
  gearImageCompact: { height: 80, width: '100%' },
  gearName: { color: theme.colors.white, fontWeight: '700' },
  gearPrice: { color: '#CBD5E1', fontSize: 12, marginTop: 3 },
  primary: { backgroundColor: theme.colors.accent, borderRadius: 10, marginTop: 12, padding: 12 },
  primaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  secondary: { borderColor: 'rgba(255,255,255,0.25)', borderRadius: 10, borderWidth: 1, marginTop: 8, padding: 12 },
  secondaryText: { color: theme.colors.white, textAlign: 'center' },
  previewBackdrop: {
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.92)',
    flex: 1,
    justifyContent: 'center',
    padding: 16
  },
  previewImage: {
    height: '82%',
    width: '100%'
  },
  previewHint: {
    color: '#CBD5E1',
    fontSize: 13,
    marginTop: 10
  }
});
