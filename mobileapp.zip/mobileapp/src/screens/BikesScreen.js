import Checkbox from 'expo-checkbox';
import { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import Filters from '../components/Filters';
import ScreenContainer from '../components/ScreenContainer';
import BikeCard from '../components/BikeCard';
import SmartImage from '../components/SmartImage';
import { bikes } from '../data/bikes';
import { gearItems } from '../data/gear';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';
import { formatMAD } from '../utils/formatCurrency';
import { openEmail, openWhatsApp } from '../utils/linking';

const defaultFilters = { brand: 'All', type: 'All', price: 'All', sort: 'Newest' };

const priceCheck = (price, range) => {
  if (range === 'Under 15000') return price < 15000;
  if (range === '15000 - 20000') return price >= 15000 && price <= 20000;
  if (range === '20000+') return price > 20000;
  return true;
};

const todayIso = () => new Date().toISOString().split('T')[0];
const addDays = (iso, days) => {
  const date = new Date(iso);
  date.setDate(date.getDate() + days);
  return date.toISOString().split('T')[0];
};

export default function BikesScreen({ route }) {
  const { t, lang } = useI18n();
  const { width } = useWindowDimensions();
  const cardWidth = Math.min(Math.max(width * 0.78, 240), 360);
  const sectionTitleSize = width < 390 ? 20 : 22;
  const pageTitleSize = width < 390 ? 24 : 28;
  const compact = width < 360;
  const [filters, setFilters] = useState(defaultFilters);
  const [selectedBikeIds, setSelectedBikeIds] = useState([]);
  const [selectedGearIds, setSelectedGearIds] = useState([]);
  const [rental, setRental] = useState({
    name: '',
    phone: '',
    startDate: todayIso(),
    endDate: addDays(todayIso(), 1),
    pickupTime: '10:00',
    returnTime: '18:00'
  });

  useEffect(() => {
    if (!route.params) return;
    const { select, gear, renterName, renterPhone, startDate, endDate, pickupTime, returnTime } = route.params;
    if (select && bikes.some((bike) => bike.id === select)) {
      setSelectedBikeIds((prev) => (prev.includes(select) ? prev : [...prev, select]));
    }
    if (Array.isArray(gear)) {
      setSelectedGearIds((prev) => Array.from(new Set([...prev, ...gear])));
    }
    setRental((prev) => ({
      ...prev,
      name: renterName ?? prev.name,
      phone: renterPhone ?? prev.phone,
      startDate: startDate ?? prev.startDate,
      endDate: endDate ?? prev.endDate,
      pickupTime: pickupTime ?? prev.pickupTime,
      returnTime: returnTime ?? prev.returnTime
    }));
  }, [route.params]);

  const filtered = useMemo(() => {
    const byFilters = bikes.filter((bike) => {
      const matchesBrand = filters.brand === 'All' || bike.brand === filters.brand;
      const matchesType = filters.type === 'All' || bike.type === filters.type;
      const matchesPrice = priceCheck(bike.price, filters.price);
      return matchesBrand && matchesType && matchesPrice;
    });
    const sorted = [...byFilters];
    if (filters.sort === 'Price: Low to High') sorted.sort((a, b) => a.price - b.price);
    if (filters.sort === 'Price: High to Low') sorted.sort((a, b) => b.price - a.price);
    return sorted;
  }, [filters]);

  const selectedBikes = bikes.filter((bike) => selectedBikeIds.includes(bike.id));
  const selectedGear = gearItems.filter((item) => selectedGearIds.includes(item.id));

  const rentalDays = useMemo(() => {
    if (!rental.startDate || !rental.endDate) return 0;
    const start = new Date(rental.startDate);
    const end = new Date(rental.endDate);
    const diff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    return Math.max(1, diff);
  }, [rental.endDate, rental.startDate]);

  const rentalTotal = useMemo(() => {
    if (!rentalDays) return 0;
    const bikesTotal = selectedBikes.reduce((sum, bike) => sum + (bike.rentalRate || 0) * rentalDays, 0);
    const gearDailyTotal = selectedGear.reduce((sum, item) => sum + (item.priceValue || 0), 0);
    return bikesTotal + gearDailyTotal * rentalDays;
  }, [rentalDays, selectedBikes, selectedGear]);

  const total = useMemo(() => {
    const bikesTotal = selectedBikes.reduce((sum, bike) => sum + bike.price, 0);
    const gearTotal = selectedGear.reduce((sum, item) => sum + item.priceValue, 0);
    return bikesTotal + gearTotal + rentalTotal;
  }, [rentalTotal, selectedBikes, selectedGear]);

  const toggleBike = (id) => setSelectedBikeIds((prev) => (prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]));
  const toggleGear = (id) => setSelectedGearIds((prev) => (prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]));

  const buildMessage = () => {
    const lines = [t.bikes.messageIntro, '', t.bikes.messageMotorcycles];
    if (selectedBikes.length) {
      selectedBikes.forEach((bike) => lines.push(`• ${bike.name} — ${formatMAD(bike.price, lang)}`));
    } else {
      lines.push(`• ${t.bikes.messageNone}`);
    }
    lines.push('', t.bikes.messageAccessories);
    if (selectedGear.length) {
      selectedGear.forEach((item) => lines.push(`• ${item.name} — ${item.price} / day`));
    } else {
      lines.push(`• ${t.bikes.messageNone}`);
    }
    lines.push('', `${t.rentals.messageLabel}:`);
    lines.push(`• ${t.rentals.renterName}: ${rental.name || '-'}`);
    lines.push(`• ${t.rentals.renterPhone}: ${rental.phone || '-'}`);
    lines.push(`• ${t.rentals.startDate}: ${rental.startDate || '-'}`);
    lines.push(`• ${t.rentals.endDate}: ${rental.endDate || '-'}`);
    lines.push(`• ${t.rentals.pickupTime}: ${rental.pickupTime || '-'}`);
    lines.push(`• ${t.rentals.returnTime}: ${rental.returnTime || '-'}`);
    lines.push('', `${t.bikes.messageTotal}: ${formatMAD(total, lang)}`);
    return lines.join('\n');
  };

  const sendWhatsApp = () => openWhatsApp('+212608188138', buildMessage());
  const sendEmail = () =>
    openEmail({
      to: 'hello@ridekey.studio',
      subject: t.bikes.emailSubject,
      body: buildMessage()
    });

  return (
    <ScreenContainer>
      <View style={styles.wrap}>
        <Text style={styles.badge}>{t.common.inventory}</Text>
        <Text style={[styles.title, { fontSize: pageTitleSize }]}>{t.bikes.title}</Text>
        <Text style={styles.models}>{filtered.length} {t.bikes.modelsAvailable}</Text>
        <Text style={styles.note}>{t.bikes.selectPrompt}</Text>

        <Filters filters={filters} setFilters={setFilters} />

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.listRow}>
          {filtered.map((bike) => (
            <View key={bike.id} style={[styles.cardWrap, { width: cardWidth }]}>
              <BikeCard bike={bike} selected={selectedBikeIds.includes(bike.id)} onSelect={toggleBike} />
            </View>
          ))}
        </ScrollView>

        <Text style={[styles.section, { fontSize: sectionTitleSize }]}>{t.bikes.accessoriesTitle}</Text>
        {gearItems.map((item) => (
          <View key={item.id} style={[styles.gearCard, compact && styles.gearCardCompact]}>
            <SmartImage
              uri={item.image}
              style={[styles.gearImage, compact && styles.gearImageCompact]}
              resizeMode="cover"
              fallbackText={item.name}
            />
            <View style={styles.gearBody}>
              <Text style={styles.gearName}>{item.name}</Text>
              <Text style={styles.gearMeta}>{item.price}</Text>
              <View style={styles.checkboxRow}>
                <Checkbox value={selectedGearIds.includes(item.id)} onValueChange={() => toggleGear(item.id)} color={theme.colors.accent} />
                <Text style={styles.checkboxText}>{t.common.select}</Text>
              </View>
            </View>
          </View>
        ))}

        <View style={styles.checkout}>
          <Text style={[styles.section, { fontSize: sectionTitleSize }]}>{t.bikes.whatsappTitle}</Text>
          <Text style={styles.totalLabel}>{t.common.total}</Text>
          <Text style={styles.total}>{formatMAD(total, lang)}</Text>

          <TextInput style={styles.input} placeholder={t.rentals.renterName} placeholderTextColor="#94A3B8" value={rental.name} onChangeText={(v) => setRental({ ...rental, name: v })} />
          <TextInput style={styles.input} placeholder={t.rentals.renterPhone} placeholderTextColor="#94A3B8" value={rental.phone} onChangeText={(v) => setRental({ ...rental, phone: v })} />
          <TextInput style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor="#94A3B8" value={rental.startDate} onChangeText={(v) => setRental({ ...rental, startDate: v })} />
          <TextInput style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor="#94A3B8" value={rental.endDate} onChangeText={(v) => setRental({ ...rental, endDate: v })} />
          <TextInput style={styles.input} placeholder="10:00" placeholderTextColor="#94A3B8" value={rental.pickupTime} onChangeText={(v) => setRental({ ...rental, pickupTime: v })} />
          <TextInput style={styles.input} placeholder="18:00" placeholderTextColor="#94A3B8" value={rental.returnTime} onChangeText={(v) => setRental({ ...rental, returnTime: v })} />

          <View style={styles.preview}><Text style={styles.previewText}>{buildMessage()}</Text></View>

          <Pressable style={styles.primary} onPress={sendWhatsApp}><Text style={styles.primaryText}>{t.bikes.sendWhatsapp}</Text></Pressable>
          <Pressable style={styles.secondary} onPress={sendEmail}><Text style={styles.secondaryText}>{t.bikes.sendEmail}</Text></Pressable>
          <Pressable style={styles.outline} onPress={() => { setSelectedBikeIds([]); setSelectedGearIds([]); }}><Text style={styles.outlineText}>{t.bikes.clear}</Text></Pressable>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 12, marginTop: 12 },
  badge: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  title: { color: theme.colors.white, fontWeight: '700', marginTop: 2 },
  models: { color: '#94A3B8' },
  note: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 12, borderWidth: 1, color: '#CBD5E1', padding: 10 },
  listRow: { gap: 10, paddingRight: 6 },
  cardWrap: { width: 300 },
  section: { color: theme.colors.white, fontWeight: '700', marginTop: 10 },
  gearCard: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 12, borderWidth: 1, flexDirection: 'row', overflow: 'hidden' },
  gearCardCompact: { flexDirection: 'column' },
  gearImage: { backgroundColor: theme.colors.ink, borderRadius: 8, height: 96, width: 96 },
  gearImageCompact: { height: 140, width: '100%' },
  gearBody: { flex: 1, padding: 10 },
  gearName: { color: theme.colors.white, fontWeight: '700' },
  gearMeta: { color: '#CBD5E1', marginTop: 4 },
  checkboxRow: { alignItems: 'center', flexDirection: 'row', gap: 8, marginTop: 8 },
  checkboxText: { color: theme.colors.frost },
  checkout: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.12)', borderRadius: 14, borderWidth: 1, marginTop: 8, padding: 12 },
  totalLabel: { color: '#94A3B8', marginTop: 4 },
  total: { color: theme.colors.accent, fontSize: 30, fontWeight: '700' },
  input: { backgroundColor: '#0B0F1A', borderColor: 'rgba(255,255,255,0.12)', borderRadius: 10, borderWidth: 1, color: theme.colors.white, marginTop: 8, paddingHorizontal: 12, paddingVertical: 10 },
  preview: { backgroundColor: 'rgba(11,15,26,0.8)', borderColor: 'rgba(255,255,255,0.12)', borderRadius: 10, borderWidth: 1, marginTop: 10, maxHeight: 180, padding: 10 },
  previewText: { color: '#CBD5E1' },
  primary: { backgroundColor: theme.colors.accent, borderRadius: 10, marginTop: 10, padding: 12 },
  primaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  secondary: { backgroundColor: '#475569', borderRadius: 10, marginTop: 8, padding: 12 },
  secondaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  outline: { borderColor: 'rgba(255,255,255,0.25)', borderRadius: 10, borderWidth: 1, marginTop: 8, padding: 12 },
  outlineText: { color: theme.colors.white, textAlign: 'center' }
});
