import * as Clipboard from 'expo-clipboard';
import { useState } from 'react';
import { FlatList, Image, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import BikeCard from '../components/BikeCard';
import HeroSlider from '../components/HeroSlider';
import Newsletter from '../components/Newsletter';
import ScreenContainer from '../components/ScreenContainer';
import { blogs } from '../data/blogs';
import { bikes } from '../data/bikes';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';
import { openUrl } from '../utils/linking';

const brands = ['Voltstream', 'Aurora', 'Onyx', 'Sierra', 'Vortex', 'Atlas'];

export default function HomeScreen() {
  const { t } = useI18n();
  const navigation = useNavigation();
  const [copiedKey, setCopiedKey] = useState(null);
  const { width } = useWindowDimensions();
  const cardWidth = Math.min(Math.max(width * 0.78, 240), 360);
  const sectionTitleSize = width < 390 ? 22 : 24;

  const paymentMethods = [
    {
      id: 'cih',
      name: 'CIH Bank',
      logoText: 'CIH',
      url: 'https://www.cihbank.ma/',
      merchantName: 'Autobike SARL',
      accountLabel: t.payments.ribLabel,
      accountValue: '230 780 0000000000001234'
    },
    {
      id: 'orange',
      name: 'Orange Money',
      logoText: 'OM',
      url: 'https://www.orange.ma/',
      merchantName: 'Autobike SARL',
      accountLabel: t.payments.walletLabel,
      accountValue: 'OM-212-600-555-666'
    }
  ];

  const copyText = async (text, key) => {
    await Clipboard.setStringAsync(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1200);
  };

  const testimonials = [
    {
      name: t.home.testimonial1Name,
      role: t.home.testimonial1Role,
      quote: t.home.testimonial1Quote,
      image: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: t.home.testimonial2Name,
      role: t.home.testimonial2Role,
      quote: t.home.testimonial2Quote,
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80'
    }
  ];

  return (
    <ScreenContainer>
      <View style={styles.gap}>
        <HeroSlider />

        <View>
          <Text style={styles.sectionLabel}>{t.common.featured}</Text>
          <Text style={[styles.sectionTitle, { fontSize: sectionTitleSize }]}>{t.home.featuredTitle}</Text>
          <FlatList
            data={bikes.slice(0, 3)}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.rowList}
            renderItem={({ item }) => <View style={[styles.cardW, { width: cardWidth }]}><BikeCard bike={item} /></View>}
          />
          <Pressable style={styles.outlineBtn} onPress={() => navigation.navigate('Bikes')}>
            <Text style={styles.outlineBtnText}>{t.home.viewAll}</Text>
          </Pressable>
        </View>

        <View>
          <Text style={styles.sectionLabel}>{t.common.journal}</Text>
          <Text style={[styles.sectionTitle, { fontSize: sectionTitleSize }]}>{t.home.journalTitle}</Text>
          {blogs.map((blog) => (
            <View key={blog.id} style={styles.blogCard}>
              <Text style={styles.blogTag}>{blog.tag}</Text>
              <Text style={styles.blogTitle}>{blog.title}</Text>
              <Text style={styles.blogExcerpt}>{blog.excerpt}</Text>
              <Text style={styles.blogDate}>{blog.date}</Text>
            </View>
          ))}
        </View>

        <View>
          <Text style={styles.sectionLabel}>{t.payments.badge}</Text>
          <Text style={[styles.sectionTitle, { fontSize: sectionTitleSize }]}>{t.payments.title}</Text>
          <Text style={styles.note}>{t.payments.noticeBody}</Text>
          {paymentMethods.map((method) => (
            <View key={method.id} style={styles.paymentCard}>
              <Pressable onPress={() => openUrl(method.url)}>
                <Text style={styles.paymentName}>{method.name}</Text>
              </Pressable>
              <Text style={styles.paymentField}>{t.payments.merchantLabel}: {method.merchantName}</Text>
              <Pressable style={styles.copyBtn} onPress={() => copyText(method.merchantName, `${method.id}-merchant`)}>
                <Text style={styles.copyText}>{copiedKey === `${method.id}-merchant` ? t.payments.copied : t.payments.copy}</Text>
              </Pressable>
              <Text style={styles.paymentField}>{method.accountLabel}: {method.accountValue}</Text>
              <Pressable style={styles.copyBtn} onPress={() => copyText(method.accountValue, `${method.id}-account`)}>
                <Text style={styles.copyText}>{copiedKey === `${method.id}-account` ? t.payments.copied : t.payments.copy}</Text>
              </Pressable>
            </View>
          ))}
        </View>

        <View>
          <Text style={styles.sectionLabel}>{t.common.testimonials}</Text>
          <Text style={[styles.sectionTitle, { fontSize: sectionTitleSize }]}>{t.home.testimonialsTitle}</Text>
          {testimonials.map((item) => (
            <View key={item.name} style={styles.testimonialCard}>
              <Text style={styles.quote}>"{item.quote}"</Text>
              <View style={styles.profileRow}>
                <Image source={{ uri: item.image }} style={styles.avatar} />
                <View>
                  <Text style={styles.profileName}>{item.name}</Text>
                  <Text style={styles.profileRole}>{item.role}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>

        <View>
          <Text style={styles.sectionLabel}>{t.common.partners}</Text>
          <Text style={[styles.sectionTitle, { fontSize: sectionTitleSize }]}>{t.home.partnersTitle}</Text>
          <View style={styles.brandsWrap}>
            {brands.map((brand) => (
              <View key={brand} style={styles.brandPill}><Text style={styles.brandText}>{brand}</Text></View>
            ))}
          </View>
        </View>

        <View style={styles.ctaRow}>
          <Pressable style={styles.primary} onPress={() => navigation.navigate('Rentals')}>
            <Text style={styles.primaryText}>{t.rentals.title}</Text>
          </Pressable>
          <Pressable style={styles.secondary} onPress={() => navigation.navigate('Contact')}>
            <Text style={styles.secondaryText}>{t.contact.title}</Text>
          </Pressable>
        </View>

        <Newsletter />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  gap: { gap: 22, marginTop: 8 },
  sectionLabel: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  sectionTitle: { color: theme.colors.white, fontSize: 24, fontWeight: '700', marginTop: 4 },
  rowList: { gap: 12, marginTop: 12, paddingRight: 8 },
  cardW: { width: 300 },
  outlineBtn: {
    borderColor: 'rgba(255,255,255,0.2)',
    borderRadius: 999,
    borderWidth: 1,
    marginTop: 12,
    paddingVertical: 10
  },
  outlineBtnText: { color: theme.colors.white, textAlign: 'center' },
  blogCard: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 14, borderWidth: 1, marginTop: 10, padding: 12 },
  blogTag: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  blogTitle: { color: theme.colors.white, fontSize: 17, fontWeight: '700', marginTop: 4 },
  blogExcerpt: { color: '#CBD5E1', marginTop: 5 },
  blogDate: { color: '#64748B', marginTop: 8 },
  note: { color: '#CBD5E1', marginTop: 8 },
  paymentCard: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 14, borderWidth: 1, marginTop: 10, padding: 12 },
  paymentName: { color: theme.colors.white, fontSize: 17, fontWeight: '700' },
  paymentField: { color: '#CBD5E1', marginTop: 8 },
  copyBtn: { alignSelf: 'flex-start', borderColor: 'rgba(255,255,255,0.2)', borderRadius: 999, borderWidth: 1, marginTop: 8, paddingHorizontal: 12, paddingVertical: 8 },
  copyText: { color: theme.colors.white, fontSize: 12 },
  testimonialCard: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 14, borderWidth: 1, marginTop: 10, padding: 12 },
  quote: { color: '#CBD5E1' },
  profileRow: { alignItems: 'center', flexDirection: 'row', gap: 10, marginTop: 12 },
  avatar: { borderRadius: 18, height: 36, width: 36 },
  profileName: { color: theme.colors.white, fontWeight: '700' },
  profileRole: { color: '#94A3B8' },
  brandsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  brandPill: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 999, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 8 },
  brandText: { color: '#CBD5E1' },
  ctaRow: { gap: 8 },
  primary: { backgroundColor: theme.colors.accent, borderRadius: 12, padding: 12 },
  primaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  secondary: { borderColor: 'rgba(255,255,255,0.25)', borderRadius: 12, borderWidth: 1, padding: 12 },
  secondaryText: { color: theme.colors.white, textAlign: 'center' }
});
