import { StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';

export default function AboutScreen() {
  const { t } = useI18n();
  const { width } = useWindowDimensions();
  const titleSize = width < 390 ? 24 : 30;

  return (
    <ScreenContainer>
      <View style={styles.wrap}>
        <Text style={styles.badge}>{t.nav.about}</Text>
        <Text style={[styles.title, { fontSize: titleSize }]}>{t.about.title}</Text>
        <Text style={styles.copy}>{t.about.copy}</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t.about.buildTitle}</Text>
          <Text style={styles.cardText}>{t.about.buildCopy}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{t.about.trustTitle}</Text>
          <Text style={styles.cardText}>{t.about.trustCopy}</Text>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  wrap: { marginTop: 12 },
  badge: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  title: { color: theme.colors.white, fontWeight: '700', marginTop: 6 },
  copy: { color: '#CBD5E1', marginTop: 8 },
  card: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.12)', borderRadius: 16, borderWidth: 1, marginTop: 14, padding: 14 },
  cardTitle: { color: theme.colors.white, fontSize: 18, fontWeight: '700' },
  cardText: { color: '#CBD5E1', marginTop: 6 }
});
