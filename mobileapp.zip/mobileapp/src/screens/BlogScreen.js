import { StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import { blogs } from '../data/blogs';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';

export default function BlogScreen() {
  const { t } = useI18n();
  const { width } = useWindowDimensions();
  const titleSize = width < 390 ? 24 : 30;

  return (
    <ScreenContainer>
      <View style={styles.wrap}>
        <Text style={styles.badge}>{t.nav.blog}</Text>
        <Text style={[styles.title, { fontSize: titleSize }]}>{t.blog.title}</Text>
        {blogs.map((blog) => (
          <View key={blog.id} style={styles.card}>
            <Text style={styles.tag}>{blog.tag}</Text>
            <Text style={styles.cardTitle}>{blog.title}</Text>
            <Text style={styles.excerpt}>{blog.excerpt}</Text>
            <Text style={styles.date}>{blog.date}</Text>
          </View>
        ))}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  wrap: { marginTop: 12 },
  badge: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  title: { color: theme.colors.white, fontWeight: '700', marginTop: 6 },
  card: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 14, borderWidth: 1, marginTop: 10, padding: 12 },
  tag: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  cardTitle: { color: theme.colors.white, fontSize: 18, fontWeight: '700', marginTop: 4 },
  excerpt: { color: '#CBD5E1', marginTop: 5 },
  date: { color: '#64748B', marginTop: 8 }
});
