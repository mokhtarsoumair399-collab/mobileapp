import Checkbox from 'expo-checkbox';
import { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import ScreenContainer from '../components/ScreenContainer';
import { bikes } from '../data/bikes';
import { gearItems } from '../data/gear';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';
import { openEmail, openWhatsApp } from '../utils/linking';

const todayIso = () => new Date().toISOString().split('T')[0];
const addDays = (iso, days) => {
  const date = new Date(iso);
  date.setDate(date.getDate() + days);
  return date.toISOString().split('T')[0];
};

export default function RentalsScreen({ navigation }) {
  const { t } = useI18n();
  const { width } = useWindowDimensions();
  const titleSize = width < 390 ? 24 : 30;
  const sectionSize = width < 390 ? 18 : 20;
  const [form, setForm] = useState({
    bikeId: bikes[0]?.id || '',
    name: '',
    phone: '',
    startDate: todayIso(),
    endDate: addDays(todayIso(), 1),
    pickupTime: '10:00',
    returnTime: '18:00'
  });
  const [selectedGearIds, setSelectedGearIds] = useState([]);

  const selectedGearNames = useMemo(() => {
    return selectedGearIds.map((id) => gearItems.find((item) => item.id === id)?.name || id).join(', ');
  }, [selectedGearIds]);

  const checkoutParams = {
    select: form.bikeId,
    gear: selectedGearIds,
    renterName: form.name,
    renterPhone: form.phone,
    startDate: form.startDate,
    endDate: form.endDate,
    pickupTime: form.pickupTime,
    returnTime: form.returnTime
  };

  const emailBody = [
    `${t.rentals.badge}: ${t.rentals.title}`,
    `${t.rentals.selectBike}: ${bikes.find((bike) => bike.id === form.bikeId)?.name || '-'}`,
    `${t.rentals.renterName}: ${form.name || '-'}`,
    `${t.rentals.renterPhone}: ${form.phone || '-'}`,
    `${t.rentals.startDate}: ${form.startDate}`,
    `${t.rentals.endDate}: ${form.endDate}`,
    `${t.rentals.pickupTime}: ${form.pickupTime}`,
    `${t.rentals.returnTime}: ${form.returnTime}`,
    `${t.bikes.accessoriesTitle}: ${selectedGearNames || t.bikes.messageNone}`
  ].join('\n');

  const handleEmail = () =>
    openEmail({
      to: 'hello@ridekey.studio',
      subject: 'Ridekey rental request',
      body: emailBody
    });

  const handleWhatsApp = () => openWhatsApp('+212608188138', emailBody);

  return (
    <ScreenContainer>
      <View style={styles.wrap}>
        <Text style={styles.badge}>{t.rentals.badge}</Text>
        <Text style={[styles.title, { fontSize: titleSize }]}>{t.rentals.title}</Text>

        <View style={styles.card}>
          <View style={styles.pickerWrap}>
            <Picker mode="dialog" selectedValue={form.bikeId} onValueChange={(bikeId) => setForm({ ...form, bikeId })} style={styles.picker}>
              {bikes.map((bike) => <Picker.Item key={bike.id} label={bike.name} value={bike.id} />)}
            </Picker>
          </View>

          <TextInput style={styles.input} placeholder={t.rentals.renterName} placeholderTextColor="#94A3B8" value={form.name} onChangeText={(v) => setForm({ ...form, name: v })} />
          <TextInput style={styles.input} placeholder={t.rentals.renterPhone} placeholderTextColor="#94A3B8" value={form.phone} onChangeText={(v) => setForm({ ...form, phone: v })} />
          <TextInput style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor="#94A3B8" value={form.startDate} onChangeText={(v) => setForm({ ...form, startDate: v })} />
          <TextInput style={styles.input} placeholder="YYYY-MM-DD" placeholderTextColor="#94A3B8" value={form.endDate} onChangeText={(v) => setForm({ ...form, endDate: v })} />
          <TextInput style={styles.input} placeholder="10:00" placeholderTextColor="#94A3B8" value={form.pickupTime} onChangeText={(v) => setForm({ ...form, pickupTime: v })} />
          <TextInput style={styles.input} placeholder="18:00" placeholderTextColor="#94A3B8" value={form.returnTime} onChangeText={(v) => setForm({ ...form, returnTime: v })} />

          <Text style={[styles.section, { fontSize: sectionSize }]}>{t.bikes.accessoriesTitle}</Text>
          {gearItems.map((item) => (
            <View key={item.id} style={styles.gearRow}>
              <Text style={styles.gearText}>{item.name}</Text>
              <Checkbox
                value={selectedGearIds.includes(item.id)}
                onValueChange={() =>
                  setSelectedGearIds((prev) =>
                    prev.includes(item.id) ? prev.filter((v) => v !== item.id) : [...prev, item.id]
                  )
                }
                color={theme.colors.accent}
              />
            </View>
          ))}

          <Pressable style={styles.primary} onPress={handleWhatsApp}>
            <Text style={styles.primaryText}>{t.rentals.sendWhatsapp}</Text>
          </Pressable>
          <Pressable style={styles.secondary} onPress={handleEmail}>
            <Text style={styles.secondaryText}>{t.contact.sendEmail}</Text>
          </Pressable>
          <Pressable style={styles.outline} onPress={() => navigation.navigate('Bikes', checkoutParams)}>
            <Text style={styles.outlineText}>Continue to Bikes</Text>
          </Pressable>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  wrap: { marginTop: 12 },
  badge: { color: theme.colors.accent, fontSize: 12, textTransform: 'uppercase' },
  title: { color: theme.colors.white, fontWeight: '700', marginTop: 6 },
  card: { backgroundColor: theme.colors.night, borderColor: 'rgba(255,255,255,0.1)', borderRadius: 14, borderWidth: 1, gap: 8, marginTop: 10, padding: 12 },
  pickerWrap: { backgroundColor: '#0B0F1A', borderColor: 'rgba(255,255,255,0.12)', borderRadius: 10, borderWidth: 1, overflow: 'hidden' },
  picker: { color: theme.colors.white, fontSize: 15, height: 50 },
  input: { backgroundColor: '#0B0F1A', borderColor: 'rgba(255,255,255,0.12)', borderRadius: 10, borderWidth: 1, color: theme.colors.white, paddingHorizontal: 12, paddingVertical: 10 },
  section: { color: theme.colors.white, fontWeight: '700', marginTop: 8 },
  gearRow: { alignItems: 'center', borderColor: 'rgba(255,255,255,0.08)', borderRadius: 10, borderWidth: 1, flexDirection: 'row', justifyContent: 'space-between', padding: 10 },
  gearText: { color: '#CBD5E1', flex: 1, marginRight: 8 },
  primary: { backgroundColor: theme.colors.accent, borderRadius: 10, marginTop: 8, padding: 12 },
  primaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  secondary: { backgroundColor: '#475569', borderRadius: 10, marginTop: 6, padding: 12 },
  secondaryText: { color: theme.colors.white, fontWeight: '700', textAlign: 'center' },
  outline: { borderColor: 'rgba(255,255,255,0.2)', borderRadius: 10, borderWidth: 1, marginTop: 6, padding: 12 },
  outlineText: { color: theme.colors.white, textAlign: 'center' }
});
