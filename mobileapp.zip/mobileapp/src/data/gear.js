export const gearItems = [
  {
    id: 'rsr048-drymaster-rain-suit',
    name: 'RSR048 DRYMASTER RAIN SUIT',
    category: 'On/Off Road',
    rating: 5,
    price: 'MAD 47.90 – 55.40',
    priceValue: 47.9,
    image: 'https://images.unsplash.com/photo-1723662307718-5b124f378f39?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1723662307718-5b124f378f39?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    cta: 'Read more'
  },
  {
    id: 'hjc-cl-y-solid-helmet',
    name: 'HJC CL-Y Solid Helmet',
    category: 'Racing',
    rating: 4,
    price: 'MAD 60.00 (was 72.00)',
    priceValue: 60,
    image: 'https://images.unsplash.com/photo-1622866962035-52a551bc7f9f?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1622866962035-52a551bc7f9f?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    cta: 'Buy Now'
  },
  {
    id: 'knee-pad-elbow-pads',
    name: 'Knee Pad Elbow Pads',
    category: 'On/Off Road',
    rating: 5,
    price: 'MAD 59.90',
    priceValue: 59.9,
    image: 'https://images.unsplash.com/photo-1541417770319-381fc687373c?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1541417770319-381fc687373c?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    cta: 'Add to cart'
  },
  {
    id: 'city-hunter-backpack',
    name: 'City Hunter Backpack',
    category: 'Scooter',
    rating: 5,
    price: 'MAD 64.80',
    priceValue: 64.8,
    image: 'https://images.unsplash.com/photo-1738669467268-7f309354f29f?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1738669467268-7f309354f29f?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    cta: 'Add to cart'
  },
  {
    id: 'vented-street-shoe',
    name: 'Vented Street Shoe',
    category: 'Racing',
    rating: 4,
    price: 'MAD 29.00 – 37.00',
    priceValue: 29,
    image: 'https://images.unsplash.com/photo-1582716510825-0ea3f7bd8334?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1582716510825-0ea3f7bd8334?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    cta: 'View products'
  },
  {
    id: 'air-carbon-v2-gloves',
    name: 'Air Carbon V2 Gloves',
    category: 'On/Off Road',
    rating: 5,
    price: 'MAD 37.00 – 45.00',
    priceValue: 37,
    image: 'https://images.unsplash.com/photo-1677672939019-622f41a465eb?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.0.3&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1677672939019-622f41a465eb?fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.0.3&q=80&w=1200',
    cta: 'View products'
  },
  {
    id: 'mountain-bike-glove',
    name: 'Mountain Bike Glove',
    category: 'On Road',
    rating: 5,
    price: 'MAD 75.00',
    priceValue: 75,
    image: 'https://images.unsplash.com/photo-1683183191020-cf86f3d45db3?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1683183191020-cf86f3d45db3?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    cta: 'Add to cart'
  },
  {
    id: 'drystar-riding-shoes',
    name: 'Drystar Riding Shoes',
    category: 'On Road',
    rating: 4,
    price: 'MAD 68.00',
    priceValue: 68,
    image: 'https://images.unsplash.com/photo-1586708594209-ed47d80b1b96?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    url: 'https://images.unsplash.com/photo-1586708594209-ed47d80b1b96?auto=format&fit=crop&fm=jpg&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&ixlib=rb-4.1.0&q=80&w=1200',
    cta: 'Add to cart'
  }
]
