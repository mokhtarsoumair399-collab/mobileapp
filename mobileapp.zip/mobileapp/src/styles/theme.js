import { StyleSheet } from 'react-native';

export const theme = {
  colors: {
    ink: '#0B0F1A',
    night: '#141B2D',
    accent: '#F97316',
    frost: '#E2E8F0',
    white: '#FFFFFF',
    muted: '#94A3B8',
    border: 'rgba(255,255,255,0.12)'
  }
};

export const sharedStyles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: theme.colors.ink
  },
  container: {
    paddingHorizontal: 16,
    paddingBottom: 28
  },
  card: {
    backgroundColor: theme.colors.night,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: 18
  },
  title: {
    color: theme.colors.white,
    fontSize: 26,
    fontWeight: '700'
  },
  subtitle: {
    color: theme.colors.accent,
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 1
  },
  text: {
    color: theme.colors.frost
  }
});
