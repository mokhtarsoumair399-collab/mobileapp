export const breakpoints = {
  small: 360,
  medium: 480,
  large: 768
};

export const getDeviceSize = (width) => {
  if (width < breakpoints.small) return 'xs';
  if (width < breakpoints.medium) return 'sm';
  if (width < breakpoints.large) return 'md';
  return 'lg';
};

export const getHorizontalPadding = (width) => {
  if (width < breakpoints.small) return 12;
  if (width < breakpoints.large) return 16;
  return 24;
};
