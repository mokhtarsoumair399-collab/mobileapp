import { Linking } from 'react-native';

export const openUrl = async (url) => {
  try {
    await Linking.openURL(url);
    return true;
  } catch {
    return false;
  }
};

export const buildWhatsAppUrl = (number, message) => {
  const digits = number.replace(/\D/g, '');
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
};

export const openWhatsApp = async (number, message) => {
  const digits = number.replace(/\D/g, '');
  const encoded = encodeURIComponent(message);
  const appUrl = `whatsapp://send?phone=${digits}&text=${encoded}`;
  const webUrl = `https://wa.me/${digits}?text=${encoded}`;
  const apiUrl = `https://api.whatsapp.com/send?phone=${digits}&text=${encoded}`;

  if (await openUrl(appUrl)) return true;
  if (await openUrl(webUrl)) return true;
  return openUrl(apiUrl);
};

export const openEmail = async ({ to, subject = '', body = '' }) => {
  const mailtoUrl = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  if (await openUrl(mailtoUrl)) return true;
  const gmailWeb = `https://mail.google.com/mail/?view=cm&to=${encodeURIComponent(to)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  return openUrl(gmailWeb);
};
