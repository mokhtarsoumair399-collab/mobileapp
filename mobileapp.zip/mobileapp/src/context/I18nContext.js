import AsyncStorage from '@react-native-async-storage/async-storage';
import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { detectLanguage, getDirection, getTranslations } from '../i18n';

const STORAGE_KEY = 'ridekey-lang';

const I18nContext = createContext({
  lang: 'en',
  dir: 'ltr',
  t: getTranslations('en'),
  setLang: () => {}
});

export const I18nProvider = ({ children }) => {
  const [lang, setLang] = useState('en');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const loadLang = async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        setLang(stored || detectLanguage());
      } finally {
        setReady(true);
      }
    };
    loadLang();
  }, []);

  useEffect(() => {
    if (ready) {
      AsyncStorage.setItem(STORAGE_KEY, lang).catch(() => {});
    }
  }, [lang, ready]);

  const value = useMemo(() => {
    return {
      lang,
      dir: getDirection(lang),
      t: getTranslations(lang),
      setLang
    };
  }, [lang]);

  if (!ready) return null;
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
};

export const useI18n = () => useContext(I18nContext);
