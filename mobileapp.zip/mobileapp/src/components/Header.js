import { useMemo } from 'react';
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View, useWindowDimensions } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useNavigation, useRoute } from '@react-navigation/native';
import { languageLabels, supportedLanguages } from '../i18n';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';
import logoImage from '../assets/logo/Logo.png';

const routeMap = [
  { route: 'Home', key: 'home' },
  { route: 'Bikes', key: 'motorcycles' },
  { route: 'Rentals', key: 'rentals' },
  { route: 'About', key: 'about' },
  { route: 'Blog', key: 'blog' },
  { route: 'Contact', key: 'contact' }
];

export default function Header() {
  const { t, lang, setLang } = useI18n();
  const navigation = useNavigation();
  const route = useRoute();
  const { width } = useWindowDimensions();
  const compact = width < 390;

  const navItems = useMemo(() => {
    return routeMap.map((item) => ({
      ...item,
      label: t.nav[item.key]
    }));
  }, [t]);

  return (
    <View style={styles.wrapper}>
      <View style={styles.topRow}>
        <View style={styles.brandRow}>
          <View style={styles.logoWrap}>
            <Image source={logoImage} style={styles.logo} resizeMode="contain" />
          </View>
          <Text style={[styles.brand, compact && styles.brandCompact]}>RideKey</Text>
        </View>
        <View style={[styles.langBlock, compact && styles.langBlockCompact]}>
          <Text style={styles.langLabel}>
            {t.common.language}: {languageLabels[lang] || lang}
          </Text>
          <View style={[styles.langWrap, compact && styles.langWrapCompact]}>
            <Picker
              mode="dialog"
              selectedValue={lang}
              style={styles.picker}
              prompt={t.common.language}
              dropdownIconColor={theme.colors.white}
              onValueChange={(value) => setLang(value)}
            >
              {supportedLanguages.map((code) => (
                <Picker.Item key={code} label={languageLabels[code] || code} value={code} />
              ))}
            </Picker>
          </View>
        </View>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.navRow}>
        {navItems.map((item) => {
          const active = route.name === item.route;
          return (
            <TouchableOpacity
              key={item.route}
              style={[styles.navBtn, active && styles.navBtnActive]}
              onPress={() => navigation.navigate(item.route)}
            >
              <Text style={[styles.navText, active && styles.navTextActive]}>{item.label}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: theme.colors.ink,
    borderBottomColor: 'rgba(255,255,255,0.08)',
    borderBottomWidth: 1,
    paddingBottom: 8
  },
  topRow: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 10
  },
  brandRow: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: 8
  },
  logoWrap: {
    alignItems: 'center',
    backgroundColor: 'rgba(20,27,45,0.95)',
    borderRadius: 999,
    height: 38,
    justifyContent: 'center',
    overflow: 'hidden',
    width: 38
  },
  logo: {
    height: 30,
    width: 30
  },
  brand: {
    color: theme.colors.white,
    fontSize: 20,
    fontWeight: '700'
  },
  brandCompact: {
    fontSize: 18
  },
  langBlock: {
    maxWidth: 250,
    width: '62%'
  },
  langBlockCompact: {
    width: '66%'
  },
  langLabel: {
    color: theme.colors.white,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
    marginBottom: 4,
    textShadowColor: 'rgba(0,0,0,0.35)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2
  },
  langWrap: {
    backgroundColor: theme.colors.night,
    borderColor: 'rgba(249,115,22,0.65)',
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden'
  },
  langWrapCompact: {
    borderRadius: 10
  },
  picker: {
    color: theme.colors.white,
    fontSize: 15,
    height: 48
  },
  navRow: {
    gap: 8,
    paddingHorizontal: 14,
    paddingTop: 6
  },
  navBtn: {
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 999,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 7
  },
  navBtnActive: {
    backgroundColor: theme.colors.accent,
    borderColor: theme.colors.accent
  },
  navText: {
    color: theme.colors.frost,
    fontSize: 13
  },
  navTextActive: {
    color: theme.colors.white,
    fontWeight: '700'
  }
});
