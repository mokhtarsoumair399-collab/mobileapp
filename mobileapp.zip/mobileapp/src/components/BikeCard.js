import { Image, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useState } from 'react';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';
import { formatMAD } from '../utils/formatCurrency';

export default function BikeCard({ bike, selected, onSelect }) {
  const navigation = useNavigation();
  const { t, lang } = useI18n();
  const [previewVisible, setPreviewVisible] = useState(false);

  return (
    <View style={styles.card}>
      <Pressable
        onPress={() => (onSelect ? onSelect(bike.id) : navigation.navigate('BikeDetails', { id: bike.id }))}
        onLongPress={() => setPreviewVisible(true)}
      >
        <Image source={{ uri: bike.image }} style={styles.image} resizeMode="cover" />
      </Pressable>
      <View style={styles.content}>
        <View style={styles.row}>
          <Text style={styles.name}>{bike.name}</Text>
          <Text style={styles.badge}>{bike.type}</Text>
        </View>
        <Text style={styles.meta}>{bike.engine} • {bike.displacement}</Text>
        <Text style={styles.price}>{formatMAD(bike.price, lang)}</Text>
        <View style={styles.actionRow}>
          <Pressable style={styles.btnOutline} onPress={() => navigation.navigate('BikeDetails', { id: bike.id })}>
            <Text style={styles.btnText}>{t.details.viewDetails}</Text>
          </Pressable>
          {onSelect ? (
            <Pressable style={[styles.btnFill, selected && styles.btnFillActive]} onPress={() => onSelect(bike.id)}>
              <Text style={styles.btnFillText}>{selected ? '✓' : t.common.select}</Text>
            </Pressable>
          ) : null}
        </View>
      </View>
      <Modal visible={previewVisible} transparent animationType="fade" onRequestClose={() => setPreviewVisible(false)}>
        <Pressable style={styles.previewBackdrop} onPress={() => setPreviewVisible(false)}>
          <Image source={{ uri: bike.image }} style={styles.previewImage} resizeMode="contain" />
          <Text style={styles.previewHint}>Tap to close</Text>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.night,
    borderColor: 'rgba(255,255,255,0.08)',
    borderRadius: 16,
    borderWidth: 1,
    overflow: 'hidden'
  },
  image: {
    aspectRatio: 16 / 9,
    minHeight: 170,
    width: '100%'
  },
  content: {
    gap: 6,
    padding: 12
  },
  row: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  name: {
    color: theme.colors.white,
    flex: 1,
    fontSize: 17,
    fontWeight: '700'
  },
  badge: {
    color: theme.colors.accent,
    fontSize: 12,
    marginLeft: 10
  },
  meta: {
    color: theme.colors.muted,
    fontSize: 12
  },
  price: {
    color: theme.colors.frost,
    fontWeight: '700'
  },
  actionRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 6
  },
  btnOutline: {
    borderColor: 'rgba(255,255,255,0.25)',
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 8
  },
  btnText: {
    color: theme.colors.white,
    fontSize: 12
  },
  btnFill: {
    backgroundColor: '#334155',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 8
  },
  btnFillActive: {
    backgroundColor: theme.colors.accent
  },
  btnFillText: {
    color: theme.colors.white,
    fontSize: 12,
    fontWeight: '700'
  },
  previewBackdrop: {
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.92)',
    flex: 1,
    justifyContent: 'center',
    padding: 16
  },
  previewImage: {
    height: '82%',
    width: '100%'
  },
  previewHint: {
    color: '#CBD5E1',
    fontSize: 13,
    marginTop: 10
  }
});
