import { StyleSheet, View } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { brands, types } from '../data/bikes';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';

export default function Filters({ filters, setFilters }) {
  const { t, lang } = useI18n();

  const formatNumber = (value) => new Intl.NumberFormat(lang).format(value);

  const priceOptions = [
    { key: 'All', label: t.filters.all },
    { key: 'Under 15000', label: t.filters.under15000.replace('15000', formatNumber(15000)) },
    {
      key: '15000 - 20000',
      label: t.filters.between15000.replace('15000', formatNumber(15000)).replace('20000', formatNumber(20000))
    },
    { key: '20000+', label: t.filters.above20000.replace('20000', formatNumber(20000)) }
  ];

  return (
    <View style={styles.wrap}>
      <View style={styles.pickerWrap}>
        <Picker mode="dialog" selectedValue={filters.brand} onValueChange={(v) => setFilters({ ...filters, brand: v })} style={styles.picker}>
          {brands.map((brand) => (
            <Picker.Item key={brand} label={brand === 'All' ? t.filters.all : brand} value={brand} />
          ))}
        </Picker>
      </View>
      <View style={styles.pickerWrap}>
        <Picker mode="dialog" selectedValue={filters.type} onValueChange={(v) => setFilters({ ...filters, type: v })} style={styles.picker}>
          {types.map((type) => (
            <Picker.Item key={type} label={type === 'All' ? t.filters.all : type} value={type} />
          ))}
        </Picker>
      </View>
      <View style={styles.pickerWrap}>
        <Picker mode="dialog" selectedValue={filters.price} onValueChange={(v) => setFilters({ ...filters, price: v })} style={styles.picker}>
          {priceOptions.map((option) => (
            <Picker.Item key={option.key} label={option.label} value={option.key} />
          ))}
        </Picker>
      </View>
      <View style={styles.pickerWrap}>
        <Picker mode="dialog" selectedValue={filters.sort} onValueChange={(v) => setFilters({ ...filters, sort: v })} style={styles.picker}>
          <Picker.Item label={t.filters.newest} value="Newest" />
          <Picker.Item label={t.filters.lowHigh} value="Price: Low to High" />
          <Picker.Item label={t.filters.highLow} value="Price: High to Low" />
        </Picker>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    gap: 10
  },
  pickerWrap: {
    backgroundColor: theme.colors.night,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden'
  },
  picker: {
    color: theme.colors.white,
    fontSize: 15,
    height: 50
  }
});
