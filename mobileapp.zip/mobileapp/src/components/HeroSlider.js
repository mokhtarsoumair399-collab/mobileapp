import { useEffect, useState } from 'react';
import { Image, ImageBackground, Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';

export default function HeroSlider() {
  const { t } = useI18n();
  const navigation = useNavigation();
  const [active, setActive] = useState(0);
  const [previewVisible, setPreviewVisible] = useState(false);
  const { width } = useWindowDimensions();
  const heroHeight = Math.min(Math.max(width * 0.62, 220), 360);
  const titleSize = width < 390 ? 24 : width < 768 ? 30 : 36;
  const buttonStack = width < 360;

  const slides = [
    { title: t.home.heroTitle1, subtitle: t.home.heroSub1, image: 'https://images.unsplash.com/photo-1623785419758-7d48241054a4?auto=format&fit=crop&w=1400&q=80' },
    { title: t.home.heroTitle2, subtitle: t.home.heroSub2, image: 'https://images.unsplash.com/photo-1759838494954-cefce6aded20?auto=format&fit=crop&w=1400&q=80' },
    { title: t.home.heroTitle3, subtitle: t.home.heroSub3, image: 'https://images.unsplash.com/photo-1762012507757-b18cdd13791b?auto=format&fit=crop&w=1400&q=80' }
  ];

  useEffect(() => {
    const id = setInterval(() => {
      setActive((prev) => (prev + 1) % slides.length);
    }, 4000);
    return () => clearInterval(id);
  }, [slides.length]);

  const slide = slides[active];

  return (
    <>
      <ImageBackground
        source={{ uri: slide.image }}
        style={[styles.hero, { height: heroHeight }]}
        imageStyle={styles.heroImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          <Text style={styles.badge}>{t.home.heroBadge}</Text>
          <Text style={[styles.title, { fontSize: titleSize }]}>{slide.title}</Text>
          <Text style={styles.subtitle}>{slide.subtitle}</Text>
          <Pressable style={styles.previewBtn} onPress={() => setPreviewVisible(true)}>
            <Text style={styles.previewBtnText}>View image</Text>
          </Pressable>
          <View style={[styles.row, buttonStack && styles.rowStack]}>
            <Pressable style={styles.primary} onPress={() => navigation.navigate('Bikes')}>
              <Text style={styles.primaryText}>{t.home.ctaExplore}</Text>
            </Pressable>
            <Pressable style={styles.secondary} onPress={() => navigation.navigate('Bikes')}>
              <Text style={styles.secondaryText}>{t.home.ctaBook}</Text>
            </Pressable>
          </View>
        </View>
      </ImageBackground>
      <Modal visible={previewVisible} transparent animationType="fade" onRequestClose={() => setPreviewVisible(false)}>
        <Pressable style={styles.previewBackdrop} onPress={() => setPreviewVisible(false)}>
          <Image source={{ uri: slide.image }} style={styles.previewImage} resizeMode="contain" />
          <Text style={styles.previewHint}>Tap to close</Text>
        </Pressable>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  hero: {
    backgroundColor: theme.colors.night,
    borderRadius: 20,
    overflow: 'hidden'
  },
  heroImage: {
    borderRadius: 20
  },
  overlay: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    flex: 1,
    justifyContent: 'center',
    padding: 18
  },
  badge: {
    color: theme.colors.accent,
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase'
  },
  title: {
    color: theme.colors.white,
    fontSize: 30,
    fontWeight: '700',
    marginTop: 8
  },
  subtitle: {
    color: '#CBD5E1',
    marginTop: 6
  },
  previewBtn: {
    alignSelf: 'flex-start',
    borderColor: 'rgba(255,255,255,0.45)',
    borderRadius: 999,
    borderWidth: 1,
    marginTop: 10,
    paddingHorizontal: 12,
    paddingVertical: 7
  },
  previewBtnText: {
    color: theme.colors.white,
    fontSize: 12,
    fontWeight: '700'
  },
  row: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 16
  },
  rowStack: {
    flexDirection: 'column'
  },
  primary: {
    backgroundColor: theme.colors.accent,
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 10
  },
  primaryText: {
    color: theme.colors.white,
    fontWeight: '700'
  },
  secondary: {
    borderColor: 'rgba(255,255,255,0.4)',
    borderRadius: 999,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 10
  },
  secondaryText: {
    color: theme.colors.white
  },
  previewBackdrop: {
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.92)',
    flex: 1,
    justifyContent: 'center',
    padding: 16
  },
  previewImage: {
    height: '82%',
    width: '100%'
  },
  previewHint: {
    color: '#CBD5E1',
    fontSize: 13,
    marginTop: 10
  }
});
