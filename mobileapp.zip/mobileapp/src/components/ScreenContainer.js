import { SafeAreaView, ScrollView, useWindowDimensions } from 'react-native';
import Header from './Header';
import Footer from './Footer';
import { sharedStyles } from '../styles/theme';
import { getHorizontalPadding } from '../utils/responsive';

export default function ScreenContainer({ children, withFooter = true }) {
  const { width } = useWindowDimensions();
  const horizontalPadding = getHorizontalPadding(width);
  const maxContentWidth = width > 900 ? 900 : '100%';

  return (
    <SafeAreaView style={sharedStyles.screen}>
      <Header />
      <ScrollView
        contentContainerStyle={[
          sharedStyles.container,
          {
            alignSelf: 'center',
            maxWidth: maxContentWidth,
            paddingHorizontal: horizontalPadding,
            width: '100%'
          }
        ]}
      >
        {children}
        {withFooter ? <Footer /> : null}
      </ScrollView>
    </SafeAreaView>
  );
}
