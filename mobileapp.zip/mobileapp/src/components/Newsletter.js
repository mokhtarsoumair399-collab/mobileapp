import { StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';

export default function Newsletter() {
  const { t } = useI18n();

  return (
    <View style={styles.wrap}>
      <Text style={styles.badge}>{t.common.newsletter}</Text>
      <Text style={styles.title}>{t.home.newsletterTitle}</Text>
      <Text style={styles.copy}>{t.home.newsletterCopy}</Text>
      <TextInput placeholder={t.common.email} placeholderTextColor="#94A3B8" style={styles.input} />
      <TouchableOpacity style={styles.btn}>
        <Text style={styles.btnText}>{t.common.subscribe}</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    backgroundColor: 'rgba(249,115,22,0.15)',
    borderRadius: 18,
    padding: 14
  },
  badge: {
    color: theme.colors.accent,
    fontSize: 12,
    textTransform: 'uppercase'
  },
  title: {
    color: theme.colors.white,
    fontSize: 20,
    fontWeight: '700',
    marginTop: 6
  },
  copy: {
    color: '#CBD5E1',
    marginTop: 6
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderColor: 'rgba(255,255,255,0.18)',
    borderRadius: 999,
    borderWidth: 1,
    color: theme.colors.white,
    marginTop: 12,
    paddingHorizontal: 14,
    paddingVertical: 10
  },
  btn: {
    alignItems: 'center',
    backgroundColor: theme.colors.accent,
    borderRadius: 999,
    marginTop: 10,
    paddingVertical: 10
  },
  btnText: {
    color: theme.colors.white,
    fontWeight: '700'
  }
});
