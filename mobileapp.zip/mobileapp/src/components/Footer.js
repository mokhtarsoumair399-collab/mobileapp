import { StyleSheet, Text, View } from 'react-native';
import { useI18n } from '../context/I18nContext';
import { theme } from '../styles/theme';

export default function Footer() {
  const { t } = useI18n();

  return (
    <View style={styles.wrap}>
      <Text style={styles.title}>{t.footer.title}</Text>
      <Text style={styles.copy}>{t.footer.copy}</Text>
      <Text style={styles.rights}>{t.footer.rights}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    borderTopColor: 'rgba(255,255,255,0.1)',
    borderTopWidth: 1,
    marginTop: 18,
    paddingTop: 14
  },
  title: {
    color: theme.colors.white,
    fontSize: 16,
    fontWeight: '700'
  },
  copy: {
    color: theme.colors.muted,
    marginTop: 6
  },
  rights: {
    color: '#64748B',
    fontSize: 12,
    marginTop: 10
  }
});
