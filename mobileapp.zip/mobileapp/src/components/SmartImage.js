import { useEffect, useMemo, useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { theme } from '../styles/theme';

export default function SmartImage({ uri, style, resizeMode = 'cover', fallbackText = 'Image unavailable' }) {
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    setFailed(false);
    setAttempt(0);
  }, [uri]);

  const resolvedUri = useMemo(() => {
    if (!uri) return '';
    if (attempt === 0) return uri;
    return `${uri}${uri.includes('?') ? '&' : '?'}retry=${attempt}`;
  }, [uri, attempt]);

  if (!uri || failed) {
    return (
      <View style={[style, styles.fallback]}>
        <Text style={styles.fallbackText} numberOfLines={2}>
          {fallbackText}
        </Text>
      </View>
    );
  }

  return (
    <Image
      source={{ uri: resolvedUri }}
      style={style}
      resizeMode={resizeMode}
      onError={() => {
        if (attempt < 2) {
          setAttempt((prev) => prev + 1);
          return;
        }
        setFailed(true);
      }}
    />
  );
}

const styles = StyleSheet.create({
  fallback: {
    alignItems: 'center',
    backgroundColor: '#1E293B',
    borderColor: 'rgba(255,255,255,0.12)',
    borderWidth: 1,
    justifyContent: 'center',
    paddingHorizontal: 8
  },
  fallbackText: {
    color: theme.colors.frost,
    fontSize: 11,
    textAlign: 'center'
  }
});
